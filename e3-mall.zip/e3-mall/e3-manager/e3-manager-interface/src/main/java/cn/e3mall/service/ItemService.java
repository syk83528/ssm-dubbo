package cn.e3mall.service;

import cn.e3mall.pojo.TbItem;

/**
 * Created by syk on 2018/2/24.
 */
public interface ItemService {

    public TbItem selectItem(Integer id);
}
