package cn.e3mall.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Created by syk on 2018/2/26.
 */
@Controller
public class PageController {

    @RequestMapping("/")
    public String index() {
        return "index";
    }

//    通用配置页面跳转
    @RequestMapping("/{page}")
    public String showPage(@PathVariable String page) {
        return page;
    }
}
